#! /bin/bash

docker build --tag avn-test .