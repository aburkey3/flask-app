#! /bin/bash

docker run -d -p 5150:5150 avn-test
echo "http://127.0.0.1:5150"